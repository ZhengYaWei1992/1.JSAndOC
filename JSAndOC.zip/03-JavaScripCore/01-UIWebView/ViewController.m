//
//  ViewController.m
//  01-UIWebView
//
//  Created by 郑亚伟 on 16/11/29.
//  Copyright © 2016年 郑亚伟. All rights reserved.
//

#import "ViewController.h"
#import "TestITableViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface ViewController ()<UIWebViewDelegate>

@end

@implementation ViewController
/**
 JavaScriptCore必须依托于UiWebView或WKWebView才能实现
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView *webView =  [[UIWebView alloc]initWithFrame:[[UIScreen mainScreen] bounds]];
    [self.view addSubview:webView];
    webView.backgroundColor = [UIColor blueColor];
    webView.delegate = self;
    NSURL *url = [NSURL URLWithString:@"http://m.dianping.com/tuan/deal/5501525"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    
    //1.获取js上下文
    //这是固定的代码
    JSContext *context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    //2.准备触发标签点击事件之后要执行的代码
    context[@"share"] =^(){
        //这里是子线程
        NSLog(@"%@",[NSThread currentThread]);
        
        //回到主线程，刷新UI
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            TestITableViewController *vc = [[TestITableViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];

        }];
        
    };
}




//当网页加载完成之后才能获取网页标签，然后用注入js，优化网页，改变网页外观
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    //拼接js的代码
    NSMutableString *stringM  = [NSMutableString string];
    //添加移除导航的js
    [stringM appendString:@"var headerTag = document.getElementsByTagName(\"header\")		[0];headerTag.parentNode.removeChild(headerTag);"];
    //添加移除橙色按钮的js
    [stringM appendString:@"var footerBtnTag = document.getElementsByClassName(\"footer-btn-fix\")[0]; footerBtnTag.parentNode.removeChild(footerBtnTag);"];
    //添加移除网页底部电脑版的js
    [stringM appendString:@"var footer = document.getElementsByClassName('footer')[0]; footer.parentNode.removeChild(footer);"];
    
    //给图片标签添加点击事件
    /*****************************************************/
    //给图片点击事件添加一个标记，用于回调（JS掉OC） 其中的share是一个标记，名字和上面的share一致
    [stringM appendString:@"var imgTag = document.getElementsByTagName('figure')[0].children[0];imgTag.onclick=function imgClick(){share()};"];
    /**
     function imgClick(){
        share()
     };
     */
    
    //webView直接提供了注入js的方法
    //[webView stringByEvaluatingJavaScriptFromString:stringM];
    
    //javaScriptCore直接提供了注入js的方法
    //1.获取JS上下文
    //这是固定的代码
    JSContext *context = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    //2.JS注入
    [context evaluateScript:stringM];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
