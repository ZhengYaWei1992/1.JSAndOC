//
//  ViewController.m
//  02-WKWebView
//
//  Created by 郑亚伟 on 16/11/30.
//  Copyright © 2016年 郑亚伟. All rights reserved.
//

#import "ViewController.h"
//使用要导入这个头文件
#import <WebKit/WebKit.h>
#import "TestTableViewController.h"

@interface ViewController ()<WKNavigationDelegate>

@end

/*
 WKWebView更节约内存，但是目前还存在一些bug，因此用的不是很广泛。
 */
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    WKWebView *webView = [[WKWebView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    /*****************注**********************/
    webView.navigationDelegate = self;
    [self.view addSubview:webView];
    NSURL *url = [NSURL URLWithString:@"http://m.dianping.com/tuan/deal/5501525"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    [webView loadRequest:request];
}

//网页即将开始加载时调用
//拦截网页加载，主动发送请求
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    //获取拦截到的请求对应的URL Str
    NSString *URLStr = navigationAction.request.URL.absoluteString;
    NSLog(@"%@",URLStr);
    
    if ([URLStr isEqualToString:@"hm://www.yaowoya.com"]) {
        NSLog(@"我点击了图片标签");
        TestTableViewController *testVC = [[TestTableViewController alloc]init];
        [self.navigationController pushViewController:testVC animated:YES];
        //不调用这个参数，程序会崩溃
        //这个参数必须调用，类似于UIWebView开始加载的时候，返回的YES.
         decisionHandler(WKNavigationActionPolicyCancel);
    }else{
        NSLog(@"没有点击图片标签");
        //这个参数必须调用，类似于UIWebView开始加载的时候，返回的YES
        decisionHandler(WKNavigationActionPolicyAllow);

    }
   
    
}

//网页已经加载完成
//注入js
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
    //拼接js的代码
    NSMutableString *stringM  = [NSMutableString string];
    //添加移除导航的js
    [stringM appendString:@"var headerTag = document.getElementsByTagName(\"header\")		[0];headerTag.parentNode.removeChild(headerTag);"];
    //添加移除橙色按钮的js
    [stringM appendString:@"var footerBtnTag = document.getElementsByClassName(\"footer-btn-fix\")[0]; footerBtnTag.parentNode.removeChild(footerBtnTag);"];
    //添加移除网页底部电脑版的js
    [stringM appendString:@"var footer = document.getElementsByClassName('footer')[0]; footer.parentNode.removeChild(footer);"];
    
    //给图片标签添加点击事件
    [stringM appendString:@"var imgTag = document.getElementsByTagName('figure')[0].children[0];imgTag.onclick=function imgClick(){window.location.href='hm://www.yaowoya.com'};"];
    //webView直接提供了注入js的方法
    //[webView stringByEvaluatingJavaScriptFromString:stringM];//UIWebView
    [webView evaluateJavaScript:stringM completionHandler:nil];//WKWebView
}
//网页已经开始加载调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
    
}

//页面加载失败调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error{
    
}
//当内容开始返回时调用，即服务器已经在想客服端发送网页数据
- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation{
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

@end
