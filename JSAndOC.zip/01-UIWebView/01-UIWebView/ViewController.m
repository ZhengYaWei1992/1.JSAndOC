//
//  ViewController.m
//  01-UIWebView
//
//  Created by 郑亚伟 on 16/11/29.
//  Copyright © 2016年 郑亚伟. All rights reserved.
//

#import "ViewController.h"
#import "TestITableViewController.h"

@interface ViewController ()<UIWebViewDelegate>

@end

@implementation ViewController
/**
 学习：注入js，优化网页。
 目标：1.移除网页中原本的导航栏  2.移除底部悬浮的广告  3.移除底部的电脑版显示
 
 OC和js的交互需要一个桥梁：桥梁救赎UIWebVIew的代理方法
 

实现的步骤：
	1.获取要删除的标签 如：var headerTag = document.getElementsByTagName("header")[0];
	2.找到你要删除的标签的父标签/父节点  headerTag.parentNode
	3.用父标签移除子标签   headerTag.parentNode.removeChild(headerTag)
	4.总结移除导航
 var headerTag = document.getElementsByTagName("header")		[0];headerTag.parentNode.removeChild(headerTag);

 */
- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView *webView =  [[UIWebView alloc]initWithFrame:[[UIScreen mainScreen] bounds]];
    [self.view addSubview:webView];
    webView.backgroundColor = [UIColor blueColor];
    webView.delegate = self;
    NSURL *url = [NSURL URLWithString:@"http://m.dianping.com/tuan/deal/5501525"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
}

/*
 给标签添加点击事件，主动发送网络请求的作用是为了方便拦截
 请求的URL自定义的作用：做标记；不同的URL对应不同的标签的点击事件
 */
//可以监听网页里面所有的网络请求
//这里可以实现JS间接调用OC的代码
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    //获取拦截到的请求对应的URL Str
    NSString *URLStr = request.URL.absoluteString;
    NSLog(@"%@",URLStr);
    if ([URLStr isEqualToString:@"hm://www.yaowoya.com"]) {
        NSLog(@"我点击了图片标签");
        TestITableViewController *testVC = [[TestITableViewController alloc]init];
        [self.navigationController pushViewController:testVC animated:YES];
    }
//    else{
//        NSLog(@"没有点击图片标签");
//    }
    
    //如果返回YES，说明拦截到的请求都会顺利的发送出去。反之，拦截的请求无法发送
    return YES;
}


//当网页加载完成之后才能获取网页标签，然后用注入js，优化网页，改变网页外观
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    //拼接js的代码
    NSMutableString *stringM  = [NSMutableString string];
    //添加移除导航的js
    [stringM appendString:@"var headerTag = document.getElementsByTagName(\"header\")		[0];headerTag.parentNode.removeChild(headerTag);"];
    //添加移除橙色按钮的js
    [stringM appendString:@"var footerBtnTag = document.getElementsByClassName(\"footer-btn-fix\")[0]; footerBtnTag.parentNode.removeChild(footerBtnTag);"];
    //添加移除网页底部电脑版的js
    [stringM appendString:@"var footer = document.getElementsByClassName('footer')[0]; footer.parentNode.removeChild(footer);"];
    
    //给图片标签添加点击事件
    [stringM appendString:@"var imgTag = document.getElementsByTagName('figure')[0].children[0];imgTag.onclick=function imgClick(){window.location.href='hm://www.yaowoya.com'};"];
    //webView直接提供了注入js的方法
    [webView stringByEvaluatingJavaScriptFromString:stringM];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
